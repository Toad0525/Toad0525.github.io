import enum
import logging
from typing import TYPE_CHECKING, cast

import discord
from discord import app_commands
from discord.ext import commands
from discord.ui import Button, Container, LayoutView, TextDisplay, button
from django.db.models import Count, Exists, F, OuterRef, Q

from ballsdex.core.discord import View
from ballsdex.core.utils.buttons import ConfirmChoiceView
from ballsdex.core.utils.menus import ChunkedListSource, Menu, SelectFormatter, TextFormatter, TextSource
from ballsdex.core.utils.sorting import FilteringChoices, SortingChoices, filter_balls, sort_balls
from ballsdex.core.utils.transformers import (
    BallEnabledTransform,
    BallInstanceTransform,
    BallTypeTransform,
    SpecialEnabledTransform,
    TradeCommandType,
)
from ballsdex.core.utils.utils import can_mention, inventory_privacy, is_staff
from bd_models.enums import DonationPolicy, QuestType
from bd_models.models import (
    BallInstance,
    DailyQuest,
    Player,
    PlayerQuestProgress,
    Special,
    Trade,
    TradeObject,
    balls,
    regimes,
)
from settings.models import settings

from .countryballs_paginator import CountryballsDuplicateSource, CountryballsViewer

if TYPE_CHECKING:
    from ballsdex.core.bot import BallsDexBot

log = logging.getLogger("ballsdex.packages.countryballs")


class DonationRequest(View):
    def __init__(
        self,
        bot: "BallsDexBot",
        interaction: discord.Interaction["BallsDexBot"],
        countryball: BallInstance,
        new_player: Player,
    ):
        super().__init__(timeout=120)
        self.bot = bot
        self.original_interaction = interaction
        self.countryball = countryball
        self.new_player = new_player

    async def interaction_check(self, interaction: discord.Interaction["BallsDexBot"], /) -> bool:
        if interaction.user.id != self.new_player.discord_id:
            await interaction.response.send_message("You are not allowed to interact with this menu.", ephemeral=True)
            return False
        return True

    async def on_timeout(self):
        for item in self.children:
            item.disabled = True  # type: ignore
        try:
            await self.original_interaction.edit_original_response(view=self)
        except discord.NotFound:
            pass
        await self.countryball.unlock()

    @button(style=discord.ButtonStyle.success, emoji="\N{HEAVY CHECK MARK}\N{VARIATION SELECTOR-16}")
    async def accept(self, interaction: discord.Interaction["BallsDexBot"], button: Button):
        self.stop()
        for item in self.children:
            item.disabled = True  # type: ignore
        self.countryball.favorite = False
        self.countryball.trade_player = self.countryball.player
        self.countryball.player = self.new_player
        await self.countryball.asave()
        trade = await Trade.objects.acreate(player1=self.countryball.trade_player, player2=self.new_player)
        await TradeObject.objects.acreate(
            trade=trade, ballinstance=self.countryball, player=self.countryball.trade_player
        )
        await interaction.response.edit_message(
            content=interaction.message.content  # type: ignore
            + "\n\N{WHITE HEAVY CHECK MARK} The donation was accepted!",
            view=self,
        )
        await self.countryball.unlock()

    @button(style=discord.ButtonStyle.danger, emoji="\N{HEAVY MULTIPLICATION X}\N{VARIATION SELECTOR-16}")
    async def deny(self, interaction: discord.Interaction["BallsDexBot"], button: Button):
        self.stop()
        for item in self.children:
            item.disabled = True  # type: ignore
        await interaction.response.edit_message(
            content=interaction.message.content  # type: ignore
            + "\n\N{CROSS MARK} The donation was denied.",
            view=self,
        )
        await self.countryball.unlock()


class DuplicateType(enum.StrEnum):
    countryballs = settings.plural_collectible_name
    specials = "specials"


class Balls(commands.GroupCog, group_name=settings.balls_slash_name):
    """
    View and manage your countryballs collection.
    """

    def __init__(self, bot: "BallsDexBot"):
        self.bot = bot

    @app_commands.command()
    @app_commands.checks.cooldown(1, 10, key=lambda i: i.user.id)
    async def list(
        self,
        interaction: discord.Interaction["BallsDexBot"],
        user: discord.User | None = None,
        sort: SortingChoices | None = None,
        reverse: bool = False,
        countryball: BallEnabledTransform | None = None,
        special: SpecialEnabledTransform | None = None,
        filter: FilteringChoices | None = None,
    ):
        """
        List your countryballs.

        Parameters
        ----------
        user: discord.User
            The user whose collection you want to view, if not yours.
        sort: SortingChoices
            Choose how countryballs are sorted. Can be used to show duplicates.
        reverse: bool
            Reverse the output of the list.
        countryball: Ball
            Filter the list by a specific countryball.
        special: Special
            Filter the list by a specific special event.
        filter: FilteringChoices
            Filter the list by a specific filter.
        """
        user_obj = user or interaction.user
        await interaction.response.defer(thinking=True)

        try:
            player = await Player.objects.aget(discord_id=user_obj.id)
        except Player.DoesNotExist:
            if user_obj == interaction.user:
                await interaction.followup.send(f"You don't have any {settings.plural_collectible_name} yet.")
            else:
                await interaction.followup.send(
                    f"{user_obj.name} doesn't have any {settings.plural_collectible_name} yet."
                )
            return
        staff = await is_staff(interaction)
        if user is not None:
            if user.id in self.bot.blacklist and not staff:
                await interaction.followup.send("You cannot view the inventory of a blacklisted user.", ephemeral=True)
                return
            if await inventory_privacy(self.bot, interaction, player, user_obj) is False:
                return

        interaction_player, _ = await Player.objects.aget_or_create(discord_id=interaction.user.id)

        blocked = await player.is_blocked(interaction_player)
        if blocked and not staff:
            await interaction.followup.send("You cannot view the list of a user that has you blocked.", ephemeral=True)
            return

        query = BallInstance.objects.filter(player=player).prefetch_related("trade_player")
        if filter:
            query = filter_balls(filter, query, interaction.guild_id)
        if countryball:
            query = query.filter(ball=countryball)
        if special:
            query = query.filter(special=special)
        if sort:
            query = sort_balls(sort, query)
        else:
            query = query.order_by("-favorite")
        query.query.add_ordering("-id")  # enforce a unique ordering to prevent mismatch during pagination

        if not await query.aexists():
            ball_txt = countryball.country if countryball else ""
            special_txt = special if special else ""

            if special_txt and ball_txt:
                combined = f"{special_txt} {ball_txt}"
            elif special_txt:
                combined = special_txt
            elif ball_txt:
                combined = ball_txt
            else:
                combined = ""

            combined_txt = f"{combined} " if combined else ""
            if user_obj == interaction.user:
                await interaction.followup.send(
                    f"You don't have any {combined_txt}{settings.plural_collectible_name} yet."
                )
            else:
                await interaction.followup.send(
                    f"{user_obj.name} doesn't have any {combined_txt}{settings.plural_collectible_name} yet."
                )
            return
        if reverse:
            query = query.reverse()

        view = CountryballsViewer()
        view.restrict_author(interaction.user.id)
        menu = Menu.countryballs(self.bot, view, view.selected, query)
        await menu.init()
        if user_obj != interaction.user:
            view.header.content = f"Viewing {user_obj.name}'s {settings.plural_collectible_name}"
        else:
            view.header.content = f"Viewing your {settings.plural_collectible_name}"
        await interaction.followup.send(view=view)

    @app_commands.command()
    @app_commands.checks.cooldown(1, 20, key=lambda i: i.user.id)
    async def completion(
        self,
        interaction: discord.Interaction["BallsDexBot"],
        ball_type: BallTypeTransform,
        user: discord.User | None = None,
        special: SpecialEnabledTransform | None = None,
        filter: FilteringChoices | None = None,
        duplicates: bool = False,
    ):
        """
        Show your current completion of the BallsDex.

        Parameters
        ----------
        ball_type: BallType
            The type of balls you want to see the completion of.
        user: discord.User
            The user whose completion you want to view, if not yours.
        special: Special
            The special you want to see the completion of
        filter: FilteringChoices
            Filter the list by a specific filter.
        duplicates: bool
            Show the completion of duplicates.
        """
        user_obj = user or interaction.user
        await interaction.response.defer(thinking=True)
        extra_text = f"{special.name} " if special else ""
        if user is not None:
            try:
                player = await Player.objects.aget(discord_id=user_obj.id)
            except Player.DoesNotExist:
                await interaction.followup.send(
                    f"{user_obj.name} doesn't have any {extra_text}{settings.plural_collectible_name} yet."
                )
                return
            staff = await is_staff(interaction)
            if user.id in self.bot.blacklist and not staff:
                await interaction.followup.send("You cannot view the completion of a blacklisted user.", ephemeral=True)
                return

            interaction_player, _ = await Player.objects.aget_or_create(discord_id=interaction.user.id)

            blocked = await player.is_blocked(interaction_player)
            if blocked and not staff:
                await interaction.followup.send(
                    "You cannot view the completion of a user that has blocked you.", ephemeral=True
                )
                return

            if await inventory_privacy(self.bot, interaction, player, user_obj) is False:
                return
        # Filter disabled balls, they do not count towards progression
        # Only ID and emoji is interesting for us
        bot_countryballs = {x: y.emoji_id for x, y in balls.items() if y.enabled and y.ball_type_id == ball_type.pk}

        # Set of ball IDs owned by the player
        filters = {"player__discord_id": user_obj.id, "ball__enabled": True, "ball__ball_type": ball_type}
        if special:
            filters["special"] = special
            bot_countryballs = {
                x: y.emoji_id
                for x, y in balls.items()
                if y.enabled
                and y.ball_type_id == ball_type.pk
                and (special.end_date is None or y.created_at is None or y.created_at < special.end_date)
            }

        if filter:
            query = filter_balls(filter, BallInstance.objects.filter(**filters), interaction.guild_id)
        else:
            query = BallInstance.objects.filter(**filters)

        if not bot_countryballs:
            await interaction.followup.send(
                (
                    f"There are no {extra_text}{settings.plural_collectible_name} of type "
                    f"**{ball_type.name}** registered on this bot yet."
                ),
                ephemeral=True,
            )
            return

        if duplicates:
            query = query.values("ball_id").annotate(count=Count("ball_id")).filter(count__gt=1)

        owned_countryballs = set(
            [
                x[0]
                async for x in query.filter(**filters)
                .distinct()  # Do not query everything
                .values_list("ball_id")
            ]
        )

        special_str = f" ({special.name})" if special else ""
        original_catcher_string = " " + filter.value.replace("_", " ") + " " if filter else ""
        duplicates_str = " duplicates" if duplicates else ""
        text = (
            f"## {settings.bot_name}{original_catcher_string}{special_str}{duplicates_str} "
            f"**{ball_type.name}** progression: "
            f"**{round(len(owned_countryballs) / len(bot_countryballs) * 100, 1)}%**\n"
        )

        def fill_fields(title: str, emoji_ids: set[int]):
            nonlocal text
            text += f"### {title}\n"
            if not emoji_ids:
                text += "Nothing yet.\n"
                return
            for emoji_id in emoji_ids:
                emoji = self.bot.get_emoji(emoji_id)
                if not emoji:
                    continue
                text += f"{emoji} "
            text += "\n"

        # Group balls by regime (category section) for display
        regime_groups: dict[str, dict[int, int]] = {}
        for ball_id, emoji_id in bot_countryballs.items():
            ball_obj = balls.get(ball_id)
            if ball_obj:
                regime = regimes.get(ball_obj.regime_id)
                regime_name = regime.name if regime else "Other"
            else:
                regime_name = "Other"
            if regime_name not in regime_groups:
                regime_groups[regime_name] = {}
            regime_groups[regime_name][ball_id] = emoji_id

        all_complete = True
        for regime_name, regime_balls in sorted(regime_groups.items()):
            owned_in_group = {regime_balls[x] for x in owned_countryballs if x in regime_balls}
            missing_in_group = {v for k, v in regime_balls.items() if k not in owned_countryballs}
            fill_fields(f"{regime_name} - Owned", owned_in_group)
            if missing_in_group:
                fill_fields(f"{regime_name} - Missing", missing_in_group)
                all_complete = False
            else:
                text += f"### :tada: {regime_name} complete!\n"
        if all_complete and regime_groups:
            text += f"### :tada: No missing {settings.plural_collectible_name}, congratulations! :tada:"

        view = LayoutView()
        container = Container()
        if user is not None and user != interaction.user:
            header = TextDisplay(f"Viewing {user_obj.display_name}'s completion")
            container.add_item(header)
        display = TextDisplay("")
        container.add_item(display)
        view.add_item(container)
        menu = Menu(self.bot, view, TextSource(text, delims=[" \n###", " "]), TextFormatter(display))
        await menu.init()
        await interaction.followup.send(view=view)

    @app_commands.command()
    @app_commands.checks.cooldown(1, 5, key=lambda i: i.user.id)
    async def info(
        self,
        interaction: discord.Interaction["BallsDexBot"],
        countryball: BallInstanceTransform,
        special: SpecialEnabledTransform | None = None,
    ):
        """
        Display info from a specific countryball.

        Parameters
        ----------
        countryball: BallInstance
            The countryball you want to inspect
        special: Special
            Filter the results of autocompletion to a special event. Ignored afterwards.
        """
        if not countryball:
            return
        await interaction.response.defer(thinking=True)
        content, file, view = await countryball.prepare_for_message(interaction)
        await interaction.followup.send(content=content, file=file, view=view)
        file.close()

    @app_commands.command()
    @app_commands.checks.cooldown(1, 5, key=lambda i: i.user.id)
    async def last(
        self,
        interaction: discord.Interaction["BallsDexBot"],
        user: discord.User | None = None,
        filter: FilteringChoices | None = None,
    ):
        """
        Display info of your or another users last caught countryball.

        Parameters
        ----------
        user: discord.Member
            The user you would like to see
        filter: FilteringChoices
            Filter the last caught countryball by a specific filter.
            Only works if the user has caught at least one countryball.
        """
        user_obj = user if user else interaction.user
        await interaction.response.defer(thinking=True)
        try:
            player = await Player.objects.aget(discord_id=user_obj.id)
        except Player.DoesNotExist:
            msg = f"{'You do' if user is None else f'{user_obj.display_name} does'}"
            await interaction.followup.send(
                f"{msg} not have any {settings.plural_collectible_name} yet.", ephemeral=True
            )
            return

        staff = await is_staff(interaction)
        if user is not None:
            if user.id in self.bot.blacklist and not staff:
                await interaction.followup.send(
                    (f"You cannot view the last caught {settings.collectible_name} of a blacklisted user."),
                    ephemeral=True,
                )
                return
            if await inventory_privacy(self.bot, interaction, player, user_obj) is False:
                return

        interaction_player, _ = await Player.objects.aget_or_create(discord_id=interaction.user.id)

        blocked = await player.is_blocked(interaction_player)
        if blocked and not staff:
            await interaction.followup.send(
                f"You cannot view the last caught {settings.collectible_name} of a user that has blocked you.",
                ephemeral=True,
            )
            return

        query = player.balls.select_related("ball", "trade_player").all()
        filter_msg = ""
        if filter:
            filter_msg = f" with the `{filter.value.replace('_', ' ')}` filter"
            query = filter_balls(filter, query, interaction.guild_id)
        countryball = await query.order_by("-id").afirst()
        if not countryball:
            msg = f"{'You do' if user is None else f'{user_obj.display_name} does'}"
            await interaction.followup.send(
                f"{msg} not have any {settings.plural_collectible_name} yet.", ephemeral=True
            )
            return

        content, file, view = await countryball.prepare_for_message(interaction)
        if user is not None and user.id != interaction.user.id:
            content = (
                f"You are viewing {user.display_name}'s last caught {settings.collectible_name}{filter_msg}.\n{content}"
            )
        else:
            content = f"You are viewing your last caught {settings.collectible_name}{filter_msg}.\n" + content
        await interaction.followup.send(content=content, file=file, view=view)
        file.close()

    @app_commands.command()
    async def favorite(
        self,
        interaction: discord.Interaction["BallsDexBot"],
        countryball: BallInstanceTransform,
        special: SpecialEnabledTransform | None = None,
    ):
        """
        Set favorite countryballs.

        Parameters
        ----------
        countryball: BallInstance
            The countryball you want to set/unset as favorite
        special: Special
            Filter the results of autocompletion to a special event. Ignored afterwards.
        """
        if not countryball:
            return

        if settings.max_favorites == 0:
            await interaction.response.send_message(
                f"You cannot set favorite {settings.plural_collectible_name} in this bot."
            )
            return

        if not countryball.favorite:
            try:
                player = await Player.objects.aget(discord_id=interaction.user.id)
            except Player.DoesNotExist:
                await interaction.response.send_message(
                    f"You don't have any {settings.plural_collectible_name} yet.", ephemeral=True
                )
                return

            grammar = (
                f"{settings.collectible_name}" if settings.max_favorites == 1 else f"{settings.plural_collectible_name}"
            )
            if await player.balls.filter(favorite=True).acount() >= settings.max_favorites:
                await interaction.response.send_message(
                    f"You cannot set more than {settings.max_favorites} favorite {grammar}.", ephemeral=True
                )
                return

            countryball.favorite = True  # type: ignore
            await countryball.asave()
            emoji = self.bot.get_emoji(countryball.countryball.emoji_id) or ""
            await interaction.response.send_message(
                f"{emoji} `#{countryball.pk:0X}` {countryball.countryball.country} "
                f"is now a favorite {settings.collectible_name}!",
                ephemeral=True,
            )

        else:
            countryball.favorite = False  # type: ignore
            await countryball.asave()
            emoji = self.bot.get_emoji(countryball.countryball.emoji_id) or ""
            await interaction.response.send_message(
                f"{emoji} `#{countryball.pk:0X}` {countryball.countryball.country} "
                f"isn't a favorite {settings.collectible_name} anymore.",
                ephemeral=True,
            )

    @app_commands.command(extras={"trade": TradeCommandType.PICK})
    async def give(
        self,
        interaction: discord.Interaction["BallsDexBot"],
        user: discord.User,
        countryball: BallInstanceTransform,
        special: SpecialEnabledTransform | None = None,
    ):
        """
        Give a countryball to a user.

        Parameters
        ----------
        user: discord.User
            The user you want to give a countryball to
        countryball: BallInstance
            The countryball you're giving away
        special: Special
            Filter the results of autocompletion to a special event. Ignored afterwards.
        """
        if not countryball:
            return
        if not countryball.is_tradeable:
            await interaction.response.send_message(
                f"You cannot donate this {settings.collectible_name}.", ephemeral=True
            )
            return
        if user.bot:
            await interaction.response.send_message("You cannot donate to bots.", ephemeral=True)
            return
        if await countryball.is_locked():
            await interaction.response.send_message(
                f"This {settings.collectible_name} is currently locked for a trade. Please try again later.",
                ephemeral=True,
            )
            return
        favorite = countryball.favorite
        if favorite:
            view = ConfirmChoiceView(
                interaction,
                accept_message=f"{settings.collectible_name.title()} donated.",
                cancel_message="This request has been cancelled.",
            )
            await interaction.response.send_message(
                f"This {settings.collectible_name} is a favorite, are you sure you want to donate it?",
                view=view,
                ephemeral=True,
            )
            await view.wait()
            if not view.value:
                return
            interaction = view.interaction_response
        else:
            await interaction.response.defer()
        await countryball.lock_for_trade()
        new_player, _ = await Player.objects.aget_or_create(discord_id=user.id)
        old_player = countryball.player

        if new_player == old_player:
            await interaction.followup.send(
                f"You cannot give a {settings.collectible_name} to yourself.", ephemeral=True
            )
            await countryball.unlock()
            return
        if new_player.donation_policy == DonationPolicy.ALWAYS_DENY:
            await interaction.followup.send(
                "This player does not accept donations. You can use trades instead.", ephemeral=True
            )
            await countryball.unlock()
            return

        friendship = await new_player.is_friend(old_player)
        if new_player.donation_policy == DonationPolicy.FRIENDS_ONLY:
            if not friendship:
                await interaction.followup.send(
                    "This player only accepts donations from friends, use trades instead.", ephemeral=True
                )
                await countryball.unlock()
                return
        blocked = await new_player.is_blocked(old_player)
        if blocked:
            await interaction.followup.send("You cannot interact with a user that has blocked you.", ephemeral=True)
            await countryball.unlock()
            return
        if new_player.discord_id in self.bot.blacklist:
            await interaction.followup.send("You cannot donate to a blacklisted user.", ephemeral=True)
            await countryball.unlock()
            return
        elif new_player.donation_policy == DonationPolicy.REQUEST_APPROVAL:
            await interaction.followup.send(
                f"Hey {user.mention}, {interaction.user.name} wants to give you "
                f"{countryball.description(include_emoji=True, bot=self.bot, is_trade=True)}!\n"
                "Do you accept this donation?",
                view=DonationRequest(self.bot, interaction, countryball, new_player),
                allowed_mentions=await can_mention([new_player, old_player]),
            )
            return

        countryball.player = new_player
        countryball.trade_player = old_player
        countryball.favorite = False
        await countryball.asave()

        trade = await Trade.objects.acreate(player1=old_player, player2=new_player)
        await TradeObject.objects.acreate(trade=trade, ballinstance=countryball, player=old_player)

        cb_txt = (
            countryball.description(short=True, include_emoji=True, bot=self.bot, is_trade=True)
            + f" (`{countryball.attack_bonus:+}%/{countryball.health_bonus:+}%`)"
        )
        if favorite:
            await interaction.followup.send(
                f"{interaction.user.mention}, you just gave the "
                f"{settings.collectible_name} {cb_txt} to {user.mention}!",
                allowed_mentions=await can_mention([new_player, old_player]),
            )
        else:
            await interaction.followup.send(
                f"You just gave the {settings.collectible_name} {cb_txt} to {user.mention}!",
                allowed_mentions=await can_mention([new_player]),
            )
        await countryball.unlock()

    @app_commands.command()
    async def count(
        self,
        interaction: discord.Interaction["BallsDexBot"],
        countryball: BallEnabledTransform | None = None,
        special: SpecialEnabledTransform | None = None,
        current_server: bool = False,
    ):
        """
        Count how many countryballs you have.

        Parameters
        ----------
        countryball: Ball
            The countryball you want to count
        special: Special
            The special you want to count
        current_server: bool
            Only count countryballs caught in the current server
        """
        if interaction.response.is_done():
            return

        assert interaction.guild
        filters = {}
        if countryball:
            filters["ball"] = countryball
        if special:
            filters["special"] = special
        if current_server:
            filters["server_id"] = interaction.guild.id
        filters["player__discord_id"] = interaction.user.id

        await interaction.response.defer(ephemeral=True, thinking=True)

        balls = await BallInstance.objects.filter(**filters).acount()
        country = f"{countryball.country} " if countryball else ""
        plural = "s" if balls > 1 or balls == 0 else ""
        special_str = f"{special.name} " if special else ""
        guild = f" caught in {interaction.guild.name}" if current_server else ""

        await interaction.followup.send(
            f"You have {balls:,} {special_str}{country}{settings.collectible_name}{plural}{guild}."
        )

    @app_commands.command()
    @app_commands.checks.cooldown(1, 20, key=lambda i: i.user.id)
    async def duplicate(
        self, interaction: discord.Interaction["BallsDexBot"], type: DuplicateType, limit: int | None = None
    ):
        """
        Shows your most duplicated countryballs or specials.

        Parameters
        ----------
        type: DuplicateType
            Type of duplicate to check (countryballs or specials).
        limit: int | None
            The amount of countryballs to show, can only be used with `countryballs`.
        """
        await interaction.response.defer(thinking=True, ephemeral=True)

        player, _ = await Player.objects.aget_or_create(discord_id=interaction.user.id)
        is_special = type == DuplicateType.specials
        queryset = BallInstance.objects.filter(player=player)

        if is_special:
            queryset = queryset.filter(special_id__isnull=False).prefetch_related("special")
            annotations = {"name": F("special__name"), "emoji": F("special__emoji"), "value_id": F("special_id")}
            apply_limit = False
        else:
            queryset = queryset.filter(ball__tradeable=True)
            annotations = {"name": F("ball__country"), "emoji": F("ball__emoji_id"), "value_id": F("ball_id")}
            apply_limit = True

        query = (
            queryset.values(annotations["value_id"].name)
            .annotate(**annotations, count=Count("value_id"))
            .order_by("-count")
        )

        if apply_limit and limit is not None:
            query = query[:limit]

        if not await query.aexists():
            await interaction.followup.send(
                f"You don't have any {type.value} duplicates in your inventory.", ephemeral=True
            )
            return

        entries = [
            discord.SelectOption(
                label=item["name"],
                emoji=self.bot.get_emoji(item["emoji"]) or item["emoji"],
                description=f"Count: {item['count']}",
                value=item["value_id"],
            )
            async for item in query
        ]

        view = CountryballsDuplicateSource(is_special)
        view.header.content = f"View your duplicate {type.value}."
        menu = Menu(self.bot, view, ChunkedListSource(entries), SelectFormatter(view.callback))
        await menu.init()
        await interaction.followup.send(view=view)

    @app_commands.command()
    @app_commands.checks.cooldown(1, 20, key=lambda i: i.user.id)
    async def compare(
        self,
        interaction: discord.Interaction["BallsDexBot"],
        user: discord.User,
        special: SpecialEnabledTransform | None = None,
        duplicates: bool = False,
    ):
        """
        Compare your countryballs with another user.

        Parameters
        ----------
        user: discord.User
            The user you want to compare with
        special: Special
            Filter the results of the comparison to a special event.
        duplicates: bool
            Whether to compare duplicates.
        """
        await interaction.response.defer(thinking=True)
        if interaction.user == user:
            await interaction.followup.send("You cannot compare with yourself.", ephemeral=True)
            return

        try:
            player = await Player.objects.aget(discord_id=user.id)
        except Player.DoesNotExist:
            await interaction.followup.send(
                f"{user.display_name} doesn't have any {settings.plural_collectible_name} yet."
            )
            return

        staff = await is_staff(interaction)
        if user.id in self.bot.blacklist and not staff:
            await interaction.followup.send("You cannot compare the inventory of a blacklisted user.", ephemeral=True)
            return

        if await inventory_privacy(self.bot, interaction, player, user) is False:
            return

        bot_countryballs = {x: y.emoji_id for x, y in balls.items() if y.enabled}
        if special:
            bot_countryballs = {
                x: y.emoji_id
                for x, y in balls.items()
                if y.enabled and (special.end_date is None or y.created_at is None or y.created_at < special.end_date)
            }

        player1, _ = await Player.objects.aget_or_create(discord_id=interaction.user.id)
        player2, _ = await Player.objects.aget_or_create(discord_id=user.id)

        blocked = await player.is_blocked(player1)
        if blocked and not staff:
            await interaction.followup.send("You cannot compare with a user that has you blocked.", ephemeral=True)
            return

        blocked = await player.is_blocked(player2)
        if blocked and not staff:
            await interaction.followup.send("You cannot compare with a user that has you blocked.", ephemeral=True)
            return
        queryset = BallInstance.objects.filter(ball__enabled=True).distinct()
        if duplicates:
            queryset = queryset.values("ball_id").annotate(counts=Count("ball_id")).filter(counts__gt=1)
        if special:
            queryset = queryset.filter(special=special)
        user1_balls = cast(
            list[int], [x async for x in queryset.filter(player=player1).values_list("ball_id", flat=True)]
        )
        user2_balls = cast(
            list[int], [x async for x in queryset.filter(player=player2).values_list("ball_id", flat=True)]
        )

        special_str = f" ({special.name})" if special else ""
        comparison_type = "Duplicates Comparison" if duplicates else "Comparison"
        text = (
            f"## {comparison_type} of {interaction.user.display_name} and {user.display_name}'s "
            f"{settings.plural_collectible_name}{special_str}\n"
        )

        def fill_fields(title: str, ids: set[int]):
            nonlocal text
            text += f"### {title}{' duplicates' if duplicates else ''}\n"
            if not ids:
                text += "None\n"
                return

            for ball_id in ids:
                emoji = self.bot.get_emoji(bot_countryballs[ball_id])
                if not emoji:
                    continue
                text += f"{emoji} "
            text += "\n"

        all_ball_ids = set(bot_countryballs.keys())
        u1_s, u2_s = set(user1_balls), set(user2_balls)
        fill_fields("Both have", u1_s & u2_s)
        fill_fields(f"Only {interaction.user.display_name} has", u1_s - u2_s)
        fill_fields(f"Only {user.display_name} has", u2_s - u1_s)
        fill_fields("Neither have", all_ball_ids - u1_s - u2_s)

        view = LayoutView()
        container = Container()
        display = TextDisplay("")
        container.add_item(display)
        view.add_item(container)
        menu = Menu(self.bot, view, TextSource(text, delims=["\n###", " "]), TextFormatter(display))
        await menu.init()
        await interaction.followup.send(view=view)

    @app_commands.command()
    async def collection(
        self,
        interaction: discord.Interaction["BallsDexBot"],
        countryball: BallEnabledTransform | None = None,
        ephemeral: bool = False,
    ):
        """
        Show the collection of a specific countryball.

        Parameters
        ----------
        countryball: Ball
            The countryball you want to see the collection of
        ephemeral: bool
            Whether or not to send the command ephemerally.
        """
        await interaction.response.defer(thinking=True, ephemeral=ephemeral)
        player, _ = await Player.objects.aget_or_create(discord_id=interaction.user.id)

        query = (
            BallInstance.objects.filter(player=player)
            .values("player_id")
            .annotate(
                total=Count("id"),
                traded=Count("id", filter=Q(trade_player_id__isnull=False)),
                specials=Count(
                    "id",
                    filter=Q(special_id__isnull=False)
                    & ~Exists(Special.objects.filter(hidden=True, id=OuterRef("special_id"))),
                ),
            )
        )
        specials = (
            BallInstance.objects.filter(player=player)
            .exclude(special=None)
            .exclude(special__hidden=True)
            .values("special__name")
            .annotate(count=Count("special__name"))
            .order_by("-count")
        )
        if countryball:
            query = query.filter(ball=countryball)
            specials = specials.filter(ball=countryball)

        try:
            counts = await query.aget()
        except BallInstance.DoesNotExist:
            if countryball:
                await interaction.followup.send(
                    f"You don't have any {countryball.country} {settings.plural_collectible_name} yet."
                )
            else:
                await interaction.followup.send(f"You don't have any {settings.plural_collectible_name} yet.")
            return
        all_specials = Special.objects.filter(hidden=False)
        special_emojis = {x.name: x.emoji async for x in all_specials}

        desc = (
            f"**Total**: {counts['total']:,} ({counts['total'] - counts['traded']:,} caught, "
            f"{counts['traded']:,} received from trade)\n"
            f"**Total Specials**: {counts['specials']:,}\n\n"
        )
        if counts["specials"]:
            desc += "**Specials**:\n"
        async for special in specials:
            emoji = special_emojis.get(special["special__name"], "")
            desc += f"{emoji} {special['special__name']}: {special['count']:,}\n"

        embed = discord.Embed(
            title=f"Collection of {countryball.country}" if countryball else "Total Collection",
            description=desc,
            color=discord.Color.blurple(),
        )
        embed.set_author(name=interaction.user.display_name, icon_url=interaction.user.display_avatar.url)
        if countryball:
            file_location = countryball.wild_card.path
            file = discord.File(file_location, filename="countryball.png")
            embed.set_thumbnail(url="attachment://countryball.png")
            await interaction.followup.send(embed=embed, file=file)
        else:
            await interaction.followup.send(embed=embed)

    @app_commands.command()
    @app_commands.checks.cooldown(1, 10, key=lambda i: i.user.id)
    async def quests(self, interaction: discord.Interaction["BallsDexBot"]):
        """
        Show the current daily quest and your progress.
        """
        await interaction.response.defer(thinking=True, ephemeral=True)

        quest = await DailyQuest.objects.select_related("reward_ball").filter(active=True).afirst()
        if quest is None:
            await interaction.followup.send("There is no active daily quest right now. Check back later!")
            return

        player, _ = await Player.objects.aget_or_create(discord_id=interaction.user.id)
        progress = await PlayerQuestProgress.objects.filter(player=player, quest=quest).afirst()
        current = progress.progress if progress else 0
        completed = progress.completed if progress else False

        quest_type_label = QuestType(quest.quest_type).label
        target_info = ""
        if quest.quest_type == QuestType.CATCH_REGIME and quest.target_regime_id is not None:
            try:
                target_regime = await quest.target_regime  # type: ignore[misc]
                target_info = f" from the **{target_regime.name}** regime"
            except Exception:
                pass
        elif quest.quest_type == QuestType.CATCH_ECONOMY and quest.target_economy_id is not None:
            try:
                target_economy = await quest.target_economy  # type: ignore[misc]
                target_info = f" from the **{target_economy.name}** economy"
            except Exception:
                pass
        elif quest.quest_type == QuestType.CATCH_BALL_TYPE and quest.target_ball_type_id is not None:
            try:
                target_type = await quest.target_ball_type  # type: ignore[misc]
                target_info = f" of type **{target_type.name}**"
            except Exception:
                pass

        progress_bar_filled = int((current / quest.required_count) * 10) if quest.required_count > 0 else 10
        progress_bar = "█" * progress_bar_filled + "░" * (10 - progress_bar_filled)

        status = "✅ Completed!" if completed else f"{progress_bar} {current}/{quest.required_count}"

        embed = discord.Embed(
            title=f"📋 Daily Quest: {quest.name}", color=discord.Color.green() if completed else discord.Color.blurple()
        )
        if quest.description:
            embed.description = quest.description
        embed.add_field(name="Objective", value=f"{quest_type_label}{target_info}", inline=False)
        embed.add_field(name="Progress", value=status, inline=False)
        embed.add_field(name="Reward", value=f"🐷 **{quest.reward_ball}**", inline=False)
        if quest.end_date:
            embed.set_footer(text=f"Quest expires: {quest.end_date}")

        await interaction.followup.send(embed=embed)
