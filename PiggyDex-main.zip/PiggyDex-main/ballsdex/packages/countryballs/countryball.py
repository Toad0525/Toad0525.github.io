from __future__ import annotations

import logging
import math
import random
import string
from datetime import datetime
from typing import TYPE_CHECKING

import discord
from discord.ui import Button, TextInput, button
from django.utils import timezone

from ballsdex.core.discord import Modal, View
from ballsdex.core.metrics import caught_balls
from ballsdex.core.utils.utils import can_mention
from bd_models.enums import QuestType
from bd_models.models import (
    Ball,
    BallInstance,
    DailyQuest,
    Player,
    PlayerQuestProgress,
    Special,
    Trade,
    TradeObject,
    balls,
    specials,
)
from settings.models import PromptMessage, settings

if TYPE_CHECKING:
    from ballsdex.core.bot import BallsDexBot

log = logging.getLogger("ballsdex.packages.countryballs")


class CountryballNamePrompt(Modal, title=f"Catch this {settings.collectible_name}!"):
    name = TextInput(
        label=f"Name of this {settings.collectible_name}", style=discord.TextStyle.short, placeholder="Your guess"
    )

    def __init__(self, view: BallSpawnView):
        super().__init__()
        self.view = view

    async def on_error(self, interaction: discord.Interaction["BallsDexBot"], error: Exception) -> None:
        if isinstance(error, discord.NotFound) and error.code == 10062:
            return
        log.exception("An error occured in countryball catching prompt", exc_info=error)
        if interaction.response.is_done():
            await interaction.followup.send(f"An error occured with this {settings.collectible_name}.")
        else:
            await interaction.response.send_message(f"An error occured with this {settings.collectible_name}.")

    async def on_submit(self, interaction: discord.Interaction["BallsDexBot"]):
        await interaction.response.defer(thinking=True)

        player, _ = await Player.objects.aget_or_create(discord_id=interaction.user.id)
        if self.view.caught:
            slow_message = settings.get_random_message(PromptMessage.PromptType.SLOW).format(
                user=interaction.user.mention,
                collectible=settings.collectible_name,
                ball=self.view.name,
                collectibles=settings.plural_collectible_name,
                emoji=interaction.client.get_emoji(self.view.model.emoji_id),
            )

            await interaction.followup.send(slow_message, ephemeral=True, allowed_mentions=await can_mention([player]))
            return

        if not self.view.is_name_valid(self.name.value):
            if len(self.name.value) > 500:
                wrong_name = self.name.value[:500] + "..."
            else:
                wrong_name = self.name.value

            wrong_message = settings.get_random_message(PromptMessage.PromptType.WRONG).format(
                user=interaction.user.mention,
                collectible=settings.collectible_name,
                ball=self.view.name,
                collectibles=settings.plural_collectible_name,
                wrong=wrong_name,
                emoji=interaction.client.get_emoji(self.view.model.emoji_id),
            )
            await interaction.followup.send(
                wrong_message, allowed_mentions=await can_mention([player]), ephemeral=False
            )
            return

        ball, has_caught_before = await self.view.catch_ball(interaction.user, player=player, guild=interaction.guild)

        await interaction.followup.send(
            self.view.get_catch_message(ball, has_caught_before, interaction.user.mention),
            allowed_mentions=discord.AllowedMentions(users=player.can_be_mentioned),
        )
        await interaction.followup.edit_message(self.view.message.id, view=self.view)


async def _grant_quest_reward(player: Player, quest: DailyQuest, progress: PlayerQuestProgress) -> None:
    """
    Mark a quest as completed and grant the reward ball if the player doesn't already own it.
    The reward ball is non-tradeable and only one copy may be held per player.
    """
    already_owns = await BallInstance.objects.filter(player=player, ball_id=quest.reward_ball_id).aexists()
    if not already_owns:
        await BallInstance.objects.acreate(
            ball_id=quest.reward_ball_id, player=player, tradeable=False, attack_bonus=0, health_bonus=0
        )
    progress.reward_given = True
    await progress.asave(update_fields=("reward_given",))


async def update_quest_progress_catch(player: Player, ball: Ball) -> None:
    """
    Increment quest progress for catch-based quest types after a player catches a ball.
    Silently skips if no active quest exists or an error occurs.
    """
    try:
        quest = await DailyQuest.objects.filter(active=True).afirst()
        if quest is None:
            return

        quest_type = QuestType(quest.quest_type)

        # Determine whether this catch counts toward the active quest
        counts = False
        if quest_type == QuestType.CATCH_SPAWNS:
            counts = True
        elif quest_type == QuestType.CATCH_REGIME and quest.target_regime_id is not None:
            counts = ball.regime_id == quest.target_regime_id
        elif quest_type == QuestType.CATCH_ECONOMY and quest.target_economy_id is not None:
            counts = ball.economy_id is not None and ball.economy_id == quest.target_economy_id
        elif quest_type == QuestType.CATCH_BALL_TYPE and quest.target_ball_type_id is not None:
            counts = ball.ball_type_id is not None and ball.ball_type_id == quest.target_ball_type_id

        if not counts:
            return

        progress, _ = await PlayerQuestProgress.objects.aget_or_create(player=player, quest=quest)
        if progress.completed:
            return

        progress.progress += 1
        if progress.progress >= quest.required_count:
            progress.completed = True
            progress.completed_at = timezone.now()
            await progress.asave(update_fields=("progress", "completed", "completed_at"))
            await _grant_quest_reward(player, quest, progress)
        else:
            await progress.asave(update_fields=("progress",))
    except Exception:
        log.exception("Error updating quest progress for catch")


async def update_quest_progress_message(player: Player) -> None:
    """
    Increment quest progress for the SEND_MESSAGES quest type.
    Silently skips if no active quest exists or an error occurs.
    """
    try:
        quest = await DailyQuest.objects.filter(active=True, quest_type=QuestType.SEND_MESSAGES).afirst()
        if quest is None:
            return

        progress, _ = await PlayerQuestProgress.objects.aget_or_create(player=player, quest=quest)
        if progress.completed:
            return

        progress.progress += 1
        if progress.progress >= quest.required_count:
            progress.completed = True
            progress.completed_at = timezone.now()
            await progress.asave(update_fields=("progress", "completed", "completed_at"))
            await _grant_quest_reward(player, quest, progress)
        else:
            await progress.asave(update_fields=("progress",))
    except Exception:
        log.exception("Error updating quest progress for message")


class BallSpawnView(View):
    """
    BallSpawnView is a Discord UI view that represents the spawning and interaction logic for a
    countryball in the BallsDex bot. It handles user interactions, spawning mechanics, and
    countryball catching logic.

    Attributes
    ----------
    bot: BallsDexBot
    model: Ball
        The ball being spawned.
    algo: str | None
        The algorithm used for spawning, used for metrics.
    message: discord.Message
        The Discord message associated with this view once created with `spawn`.
    caught: bool
        Whether the countryball has been caught yet.
    ballinstance: BallInstance | None
        If this is set, this ball instance will be spawned instead of creating a new ball instance.
        All properties are preserved, and if successfully caught, the owner is transferred (with
        a trade entry created). Use the `from_existing` constructor to use this.
    special: Special | None
        Force the spawned countryball to have a special event attached. If None, a random one will
        be picked.
    atk_bonus: int | None
        Force a specific attack bonus if set, otherwise random range defined in config.yml.
    hp_bonus: int | None
        Force a specific health bonus if set, otherwise random range defined in config.yml.
    """

    def __init__(self, bot: "BallsDexBot", model: Ball):
        super().__init__()
        self.bot = bot
        self.model = model
        self.algo: str | None = None
        self.message: discord.Message = discord.utils.MISSING
        self.caught = False
        self.ballinstance: BallInstance | None = None
        self.special: Special | None = None
        self.atk_bonus: int | None = None
        self.hp_bonus: int | None = None
        self.og_id: int

        self.catch_button.label = settings.catch_button_label

    async def interaction_check(self, interaction: discord.Interaction["BallsDexBot"], /) -> bool:
        return await interaction.client.blacklist_check(interaction)

    async def on_timeout(self):
        self.catch_button.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass
        if self.ballinstance and not self.caught:
            await self.ballinstance.unlock()

    @button(style=discord.ButtonStyle.primary, label="Catch me!")
    async def catch_button(self, interaction: discord.Interaction["BallsDexBot"], button: Button):
        if self.caught:
            slow_message = settings.get_random_message(PromptMessage.PromptType.SLOW).format(
                user=interaction.user.mention,
                collectible=settings.collectible_name,
                ball=self.name,
                collectibles=settings.plural_collectible_name,
                emoji=interaction.client.get_emoji(self.model.emoji_id),
            )
            await interaction.response.send_message(slow_message, ephemeral=True)
        else:
            await interaction.response.send_modal(CountryballNamePrompt(self))

    @classmethod
    async def from_existing(cls, bot: "BallsDexBot", ball_instance: BallInstance):
        """
        Get an instance from an existing `BallInstance`. Instead of creating a new ball instance,
        this will transfer ownership of the existing instance when caught.

        The ball instance must be unlocked from trades, and will be locked until caught or timed
        out.
        """
        if await ball_instance.is_locked():
            raise RuntimeError("This countryball is locked for a trade")

        # prevent countryball from being traded while spawned
        await ball_instance.lock_for_trade()

        view = cls(bot, ball_instance.ball)
        view.ballinstance = ball_instance
        view.og_id = ball_instance.player.discord_id
        return view

    @classmethod
    async def get_random(cls, bot: "BallsDexBot"):
        """
        Get a new instance with a random countryball. Rarity values are taken into account.
        """
        countryballs = list(filter(lambda m: m.enabled, balls.values()))
        if not countryballs:
            raise RuntimeError("No ball to spawn")
        rarities = [x.rarity for x in countryballs]
        cb = random.choices(population=countryballs, weights=rarities, k=1)[0]
        return cls(bot, cb)

    @property
    def name(self):
        return self.model.country

    def get_random_special(self) -> Special | None:
        population = [
            x
            for x in specials.values()
            # handle null start/end dates with infinity times
            if (x.start_date or datetime.min.replace(tzinfo=timezone.get_current_timezone()))
            <= timezone.now()
            <= (x.end_date or datetime.max.replace(tzinfo=timezone.get_current_timezone()))
        ]

        if not population:
            return None

        common_weight: float = 1 - sum(x.rarity for x in population)

        if common_weight < 0:
            common_weight = 0

        weights = [x.rarity for x in population] + [common_weight]
        # None is added representing the common countryball
        special: Special | None = random.choices(population=population + [None], weights=weights, k=1)[0]

        return special

    async def spawn(self, channel: discord.TextChannel) -> bool:
        """
        Spawn a countryball in a channel.

        Parameters
        ----------
        channel: discord.TextChannel
            The channel where to spawn the countryball. Must have permission to send messages
            and upload files as a bot (not through interactions).

        Returns
        -------
        bool
            `True` if the operation succeeded, otherwise `False`. An error will be displayed
            in the logs if that's the case.
        """

        def generate_random_name():
            source = string.ascii_uppercase + string.ascii_lowercase + string.ascii_letters
            return "".join(random.choices(source, k=15))

        extension = self.model.wild_card.name.split(".")[-1]
        file_name = f"nt_{generate_random_name()}.{extension}"
        try:
            permissions = channel.permissions_for(channel.guild.me)
            if permissions.attach_files and permissions.send_messages:
                spawn_message = settings.get_random_message(PromptMessage.PromptType.SPAWN).format(
                    collectible=settings.collectible_name,
                    ball=self.name,
                    collectibles=settings.plural_collectible_name,
                    emoji=self.bot.get_emoji(self.model.emoji_id),
                )

                self.message = await channel.send(
                    spawn_message, view=self, file=discord.File(self.model.wild_card.path, filename=file_name)
                )
                return True
            else:
                log.warning("Missing permission to spawn ball in channel %s.", channel)
        except discord.Forbidden:
            log.warning(f"Missing permission to spawn ball in channel {channel}.")
        except discord.HTTPException:
            log.error("Failed to spawn ball", exc_info=True)
        return False

    def is_name_valid(self, text: str) -> bool:
        """
        Check if the prompted name is valid.

        Parameters
        ----------
        text: str
            The text entered by the user. It will be lowered and stripped of enclosing blank
            characters.

        Returns
        -------
        bool
            Whether the name matches or not.
        """
        if self.model.catch_names:
            possible_names = (self.name.lower(), *self.model.catch_names.split(";"))
        else:
            possible_names = (self.name.lower(),)
        cname = text.lower().strip()
        # Remove fancy unicode characters like ’ to replace to '
        cname = cname.replace("\u2019", "'")
        cname = cname.replace("\u2018", "'")
        cname = cname.replace("\u201c", '"')
        cname = cname.replace("\u201d", '"')
        return cname in possible_names

    async def catch_ball(
        self, user: discord.User | discord.Member, *, player: Player | None, guild: discord.Guild | None
    ) -> tuple[BallInstance, bool]:
        """
        Mark this countryball as caught and assign a new `BallInstance` (or transfer ownership if
        attribute `ballinstance` was set).

        Parameters
        ----------
        user: discord.User | discord.Member
            The user that will obtain the new countryball.
        player: Player
            If already fetched, add the player model here to avoid an additional query.
        guild: discord.Guild | None
            If caught in a guild, specify here for additional logs. Will be extracted from `user`
            if it's a member object.

        Returns
        -------
        tuple[bool, BallInstance]
            A tuple whose first value indicates if this is the first time this player catches this
            countryball. Second value is the newly created countryball.

            If `ballinstance` was set, this value is returned instead.

        Raises
        ------
        RuntimeError
            The `caught` attribute is already set to `True`. You should always check before calling
            this function that the ball was not caught.
        """
        if self.caught:
            raise RuntimeError("This ball was already caught!")
        self.caught = True
        self.catch_button.disabled = True
        caught_time = timezone.now()
        player = player or (await Player.objects.aget_or_create(discord_id=user.id))[0]
        is_new = not await BallInstance.objects.filter(player=player, ball=self.model).aexists()

        if self.ballinstance:
            # if specified, do not create a countryball but switch owner
            # it's important to register this as a trade to avoid bypass
            trade = await Trade.objects.acreate(player1=self.ballinstance.player, player2=player)
            await TradeObject.objects.acreate(
                trade=trade, player=self.ballinstance.player, ballinstance=self.ballinstance
            )
            self.ballinstance.trade_player = self.ballinstance.player
            self.ballinstance.player = player
            self.ballinstance.locked = None  # type: ignore
            await self.ballinstance.asave(update_fields=("player", "trade_player", "locked"))
            return self.ballinstance, is_new

        # stat may vary by +/- 20% of base stat
        bonus_attack = (
            self.atk_bonus
            if self.atk_bonus is not None
            else random.randint(-settings.max_attack_bonus, settings.max_attack_bonus)
        )
        bonus_health = (
            self.hp_bonus
            if self.hp_bonus is not None
            else random.randint(-settings.max_health_bonus, settings.max_health_bonus)
        )

        # check if we can spawn cards with a special background
        special: Special | None = self.special

        if not special:
            special = self.get_random_special()

        ball = await BallInstance.objects.acreate(
            ball=self.model,
            player=player,
            special=special,
            attack_bonus=bonus_attack,
            health_bonus=bonus_health,
            server_id=guild.id if guild else None,
            spawned_time=self.message.created_at,
            catch_date=caught_time,
        )

        # logging and stats
        log.log(
            logging.INFO if user.id in self.bot.catch_log else logging.DEBUG,
            f"{user} caught {settings.collectible_name} {self.model}, {special=}",
        )
        if isinstance(user, discord.Member) and user.guild.member_count:
            caught_balls.labels(
                country=self.name,
                special=special,
                # observe the size of the server, rounded to the nearest power of 10
                guild_size=10 ** math.ceil(math.log(max(user.guild.member_count - 1, 1), 10)),
                spawn_algo=self.algo,
            ).inc()

        await update_quest_progress_catch(player, self.model)

        return ball, is_new

    def get_catch_message(self, ball: BallInstance, new_ball: bool, mention: str) -> str:
        """
        Generate a user-facing message after a ball has been caught.

        Parameters
        ----------
        ball: BallInstance
            The newly created ball instance
        new_ball: bool
            Boolean indicating if this is a new countryball in completion
            (as returned by `catch_ball`)
        """
        text = ""
        if ball.specialcard and ball.specialcard.catch_phrase:
            text += f"*{ball.specialcard.catch_phrase}*\n"
        if new_ball:
            text += f"This is a **new {settings.collectible_name}** that has been added to your completion!"
        if self.ballinstance:
            text += f"This {settings.collectible_name} was dropped by <@{self.og_id}>\n"

        caught_message = (
            settings.get_random_message(PromptMessage.PromptType.CATCH).format(
                user=mention,
                collectible=settings.collectible_name,
                ball=self.name,
                collectibles=settings.plural_collectible_name,
                emoji=self.bot.get_emoji(self.model.emoji_id),
            )
            + " "
        )

        return caught_message + f"`(#{ball.pk:0X}, {ball.attack_bonus:+}%/{ball.health_bonus:+}%)`\n\n{text}"
