import importlib
import logging
from typing import TYPE_CHECKING, cast

import discord
from discord.ext import commands, tasks

from bd_models.models import GuildConfig, Player
from settings.models import settings

from .countryball import BallSpawnView, update_quest_progress_message
from .spawn import BaseSpawnManager

if TYPE_CHECKING:
    from ballsdex.core.bot import BallsDexBot

log = logging.getLogger("ballsdex.packages.countryballs")


class CountryBallsSpawner(commands.Cog):
    spawn_manager: BaseSpawnManager

    def __init__(self, bot: "BallsDexBot"):
        self.bot = bot
        self.cache: dict[int, int] = {}
        self.countryball_cls = BallSpawnView

        module_path, class_name = settings.spawn_manager.rsplit(".", 1)
        module = importlib.import_module(module_path)
        # force a reload, otherwise cog reloads won't reflect to this class
        importlib.reload(module)
        spawn_manager = getattr(module, class_name)
        self.spawn_manager = spawn_manager(bot)

    async def cog_load(self):
        self.spawn_loop.start()

    async def cog_unload(self):
        self.spawn_loop.cancel()

    @tasks.loop(minutes=15)
    async def spawn_loop(self):
        for guild_id, channel_id in list(self.cache.items()):
            guild = self.bot.get_guild(guild_id)
            if not guild:
                continue
            if guild_id in self.bot.blacklist_guild:
                continue
            channel = guild.get_channel(channel_id)
            if not channel:
                log.warning(f"Lost channel {channel_id} for guild {guild.name}.")
                del self.cache[guild_id]
                continue
            try:
                ball = await BallSpawnView.get_random(self.bot)
                ball.algo = "timer"
                await ball.spawn(cast(discord.TextChannel, channel))
            except Exception:
                log.error(f"Failed to spawn ball in guild {guild.name}", exc_info=True)

    @spawn_loop.before_loop
    async def before_spawn_loop(self):
        await self.bot.wait_until_ready()

    async def load_cache(self):
        i = 0
        async for config in GuildConfig.objects.filter(enabled=True, spawn_channel__isnull=False).only(
            "guild_id", "spawn_channel"
        ):
            self.cache[config.guild_id] = cast(int, config.spawn_channel)
            i += 1
        grammar = "" if i == 1 else "s"
        log.info(f"Loaded {i} guild{grammar} in cache.")

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or message.webhook_id is not None:
            return
        guild = message.guild
        if not guild:
            return
        if guild.id not in self.cache:
            return
        if guild.id in self.bot.blacklist_guild:
            return

        # track message-count daily quest progress for this user
        player, _ = await Player.objects.aget_or_create(discord_id=message.author.id)
        await update_quest_progress_message(player)

        result = await self.spawn_manager.handle_message(message)
        if result is False:
            return

        if isinstance(result, tuple):
            result, algo = result
        else:
            algo = settings.spawn_manager

        channel = guild.get_channel(self.cache[guild.id])
        if not channel:
            log.warning(f"Lost channel {self.cache[guild.id]} for guild {guild.name}.")
            del self.cache[guild.id]
            return
        ball = await BallSpawnView.get_random(self.bot)
        ball.algo = algo
        await ball.spawn(cast(discord.TextChannel, channel))

    @commands.Cog.listener()
    async def on_ballsdex_settings_change(
        self, guild: discord.Guild, channel: discord.TextChannel | None = None, enabled: bool | None = None
    ):
        if guild.id not in self.cache:
            if enabled is False:
                return  # do nothing
            if channel:
                self.cache[guild.id] = channel.id
            else:
                try:
                    config = await GuildConfig.objects.aget(guild_id=guild.id)
                except GuildConfig.DoesNotExist:
                    return
                else:
                    self.cache[guild.id] = cast(int, config.spawn_channel)
        else:
            if enabled is False:
                del self.cache[guild.id]
            elif channel:
                self.cache[guild.id] = channel.id
