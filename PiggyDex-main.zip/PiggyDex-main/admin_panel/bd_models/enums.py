from django.db import models


class DonationPolicy(models.IntegerChoices):
    ALWAYS_ACCEPT = 1
    REQUEST_APPROVAL = 2
    ALWAYS_DENY = 3
    FRIENDS_ONLY = 4


class PrivacyPolicy(models.IntegerChoices):
    ALLOW = 1
    DENY = 2
    SAME_SERVER = 3
    FRIENDS = 4


class MentionPolicy(models.IntegerChoices):
    ALLOW = 1
    DENY = 2


class FriendPolicy(models.IntegerChoices):
    ALLOW = 1
    DENY = 2


class TradeCooldownPolicy(models.IntegerChoices):
    COOLDOWN = 1
    BYPASS = 2


class QuestType(models.IntegerChoices):
    CATCH_SPAWNS = 1, "Catch any spawns"
    CATCH_REGIME = 2, "Catch balls from a regime"
    CATCH_ECONOMY = 3, "Catch balls from an economy"
    CATCH_BALL_TYPE = 4, "Catch balls of a type"
    SEND_MESSAGES = 5, "Send messages"
