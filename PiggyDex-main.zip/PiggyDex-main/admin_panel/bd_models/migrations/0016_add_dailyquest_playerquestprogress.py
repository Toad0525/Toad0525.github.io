import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("bd_models", "0015_balltype_ball_ball_type")]

    operations = [
        migrations.CreateModel(
            name="DailyQuest",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(help_text="Display name of this quest", max_length=128)),
                (
                    "description",
                    models.TextField(blank=True, default="", help_text="Optional description shown to players"),
                ),
                (
                    "quest_type",
                    models.SmallIntegerField(
                        choices=[
                            (1, "Catch any spawns"),
                            (2, "Catch balls from a regime"),
                            (3, "Catch balls from an economy"),
                            (4, "Catch balls of a type"),
                            (5, "Send messages"),
                        ],
                        help_text="What the player must do to complete this quest",
                    ),
                ),
                (
                    "required_count",
                    models.PositiveIntegerField(
                        help_text="How many times the action must be performed to complete the quest"
                    ),
                ),
                (
                    "active",
                    models.BooleanField(default=False, help_text="Mark this quest as the currently active daily quest"),
                ),
                (
                    "start_date",
                    models.DateField(blank=True, null=True, help_text="Date when this quest becomes available"),
                ),
                ("end_date", models.DateField(blank=True, null=True, help_text="Date when this quest expires")),
                (
                    "reward_ball",
                    models.ForeignKey(
                        help_text=(
                            "The skin/ball awarded on completion. Players can only hold 1 copy and cannot trade it."
                        ),
                        on_delete=django.db.models.deletion.CASCADE,
                        to="bd_models.ball",
                    ),
                ),
                (
                    "target_regime",
                    models.ForeignKey(
                        blank=True,
                        help_text="Required for 'Catch balls from a regime' quest type",
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="bd_models.regime",
                    ),
                ),
                (
                    "target_economy",
                    models.ForeignKey(
                        blank=True,
                        help_text="Required for 'Catch balls from an economy' quest type",
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="bd_models.economy",
                    ),
                ),
                (
                    "target_ball_type",
                    models.ForeignKey(
                        blank=True,
                        help_text="Required for 'Catch balls of a type' quest type",
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="bd_models.balltype",
                    ),
                ),
            ],
            options={
                "verbose_name": "Daily Quest",
                "verbose_name_plural": "Daily Quests",
                "db_table": "dailyquest",
                "managed": True,
            },
        ),
        migrations.CreateModel(
            name="PlayerQuestProgress",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("progress", models.PositiveIntegerField(default=0, help_text="Current completion count")),
                ("completed", models.BooleanField(default=False)),
                (
                    "reward_given",
                    models.BooleanField(
                        default=False, help_text="Whether the reward ball has been created for this player"
                    ),
                ),
                ("completed_at", models.DateTimeField(blank=True, null=True)),
                (
                    "player",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="quest_progresses",
                        to="bd_models.player",
                    ),
                ),
                (
                    "quest",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="progresses",
                        to="bd_models.dailyquest",
                    ),
                ),
            ],
            options={
                "verbose_name": "Player Quest Progress",
                "verbose_name_plural": "Player Quest Progresses",
                "db_table": "playerquestprogress",
                "managed": True,
            },
        ),
        migrations.AddConstraint(
            model_name="playerquestprogress",
            constraint=models.UniqueConstraint(fields=("player", "quest"), name="unique_player_quest"),
        ),
    ]
