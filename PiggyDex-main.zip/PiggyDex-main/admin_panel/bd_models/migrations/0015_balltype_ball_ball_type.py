# Generated migration for BallType model and ball_type ForeignKey on Ball

import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("bd_models", "0014_alter_ball_options_alter_ballinstance_options_and_more")]

    operations = [
        migrations.CreateModel(
            name="BallType",
            fields=[
                ("id", models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=64, unique=True)),
            ],
            options={"db_table": "balltype", "managed": True},
        ),
        migrations.AddField(
            model_name="ball",
            name="ball_type",
            field=models.ForeignKey(
                blank=True,
                help_text="Type category of this ball",
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                to="bd_models.balltype",
            ),
        ),
    ]
