from typing import TYPE_CHECKING, Any

from django.contrib import admin

from ..enums import QuestType
from ..models import DailyQuest, PlayerQuestProgress

if TYPE_CHECKING:
    from django.http import HttpRequest


class PlayerQuestProgressInline(admin.TabularInline):
    model = PlayerQuestProgress
    extra = 0
    readonly_fields = ("player", "progress", "completed", "reward_given", "completed_at")
    can_delete = False
    show_change_link = True

    def has_add_permission(  # pyright: ignore [reportIncompatibleMethodOverride]
        self, request: "HttpRequest", obj: "DailyQuest | None" = None
    ) -> bool:
        return False


@admin.register(DailyQuest)
class DailyQuestAdmin(admin.ModelAdmin):
    list_display = ("name", "quest_type_display", "reward_ball", "required_count", "active", "start_date", "end_date")
    list_editable = ("active",)
    list_filter = ("active", "quest_type")
    search_fields = ("name", "description")
    autocomplete_fields = ("reward_ball", "target_regime", "target_economy", "target_ball_type")
    inlines = (PlayerQuestProgressInline,)
    save_on_top = True

    fieldsets = [
        (None, {"fields": ["name", "description", "active", "start_date", "end_date"]}),
        (
            "Reward",
            {
                "description": ("Players can only hold 1 copy of the reward ball and it cannot be traded."),
                "fields": ["reward_ball"],
            },
        ),
        (
            "Quest Requirements",
            {
                "description": (
                    "Choose the quest type and how many times the action must be performed. "
                    "Fill in the matching target field for regime/economy/type quests."
                ),
                "fields": ["quest_type", "required_count", "target_regime", "target_economy", "target_ball_type"],
            },
        ),
    ]

    @admin.display(description="Quest Type")
    def quest_type_display(self, obj: DailyQuest) -> str:
        return QuestType(obj.quest_type).label

    def save_model(self, request: "HttpRequest", obj: DailyQuest, form: Any, change: bool) -> None:
        # Only one quest should be active at a time; deactivate others when activating this one
        if obj.active:
            DailyQuest.objects.exclude(pk=obj.pk).filter(active=True).update(active=False)
        super().save_model(request, obj, form, change)


@admin.register(PlayerQuestProgress)
class PlayerQuestProgressAdmin(admin.ModelAdmin):
    list_display = ("player", "quest", "progress", "completed", "reward_given", "completed_at")
    list_filter = ("completed", "reward_given", "quest")
    search_fields = ("player__discord_id",)
    readonly_fields = ("completed_at",)
    autocomplete_fields = ("player", "quest")
